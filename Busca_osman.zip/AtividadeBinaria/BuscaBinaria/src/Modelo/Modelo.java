package Modelo;
import java.util.Arrays;

public class Modelo {
    private int[] array;

    public Modelo(int[] array) {
        this.array = array;
        Arrays.sort(this.array);
    }

    public int buscaBinaria(int elemento) {
        int inicio = 0;
        int fim = array.length - 1;

        while (inicio <= fim) {
            int meio = inicio + (fim - inicio / 2);

            if (array[meio] == elemento) {
                return meio;
            } else if (array[meio] < elemento) {
                inicio = meio + 1;
            } else {
                fim = meio - 1;
            }
        }
        return -1;
    }
}

package Visao;
import java.util.Scanner;

import Controle.Controle;
import Modelo.Modelo;


public class Visao {
	
	public int obterElementoDoUsuario() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Digite o elemento a ser buscado: ");
	        return scanner.nextInt();
	    }

	    public void exibirResultado(int elemento, int indice) {
	        if (indice == -1) {
	            System.out.println("Elemento " + elemento + " não encontrado.");
	        } else {
	            System.out.println("Elemento " + elemento + " encontrado no índice " + indice);
	        }
	    }
	    
	        public static void main(String[] args) {
	            int[] array = {54, 26, 93, 17, 77, 31, 44, 55, 20, 65};

	           Modelo modelo = new Modelo(array);
	           Visao visualizacao = new Visao();
	           Controle controlador = new Controle(modelo, visualizacao);

	            controlador.buscarElemento();
	        }
	    }

	





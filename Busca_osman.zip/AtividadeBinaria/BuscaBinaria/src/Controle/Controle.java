package Controle;

import Modelo.Modelo;
import Visao.Visao;

public class Controle {
    private Modelo modelo;
    private Visao visualizacao;

    public Controle(Modelo modelo, Visao visualizacao) {
        this.modelo = modelo;
        this.visualizacao = visualizacao;
    }

    public void buscarElemento() {
        int elemento = visualizacao.obterElementoDoUsuario();
        int indice = modelo.buscaBinaria(elemento);
        visualizacao.exibirResultado(elemento, indice);
    }
}
